# Renters Insurance POC

Two separate applications: a .NET 8 controller-based API using Entity Framework Core 8 and SQL Server, and an Angular 21 standalone application styled with Bootstrap 5. No repository layer, authentication framework, carrier integration, or rating engine.

## Quick start (Windows / PowerShell)

Prerequisites: .NET 8 SDK (or newer SDK with the .NET 8 runtime), Node.js 22.12+ in the 22.x line, npm, SQL Server or SQL Server Express LocalDB, and SSMS or `sqlcmd`.

### 1. Create the database

From this folder:

```powershell
SqlLocalDB start MSSQLLocalDB
sqlcmd -S '(localdb)\MSSQLLocalDB' -E -b -i database\001-create-database.sql
```

Alternatively, run `database/001-create-database.sql` in SSMS against your SQL Server instance. The script creates `RentersInsurance` and `dbo.Quotes` if absent and is safe to rerun. It is the schema setup mechanism; EF migrations and automatic database creation are intentionally not used.

### 2. Run the API

```powershell
cd backend
dotnet restore --configfile ..\NuGet.Config
dotnet run --launch-profile http
```

API: http://localhost:5080. Health check: http://localhost:5080/health (process health, not database health).

Development uses `(localdb)\MSSQLLocalDB` in `appsettings.Development.json`. For a regular SQL Server instance, override the connection in the same terminal before running:

```powershell
$env:ConnectionStrings__RentersDb = 'Server=localhost;Database=RentersInsurance;Integrated Security=True;Encrypt=True;TrustServerCertificate=True;Connect Timeout=5'
dotnet run --launch-profile http
```

The Windows account running the API needs permission to insert into the database. `TrustServerCertificate=True` and HTTP are local development settings. Do not commit database passwords. The base configuration targets `localhost` SQL Server; the Development configuration overrides it with LocalDB.

### 3. Run Angular in a separate terminal

```powershell
cd frontend
npm ci
npm start
```

Open http://localhost:4200. API URL: `frontend/src/environments/environment.ts`. CORS explicitly allows `http://localhost:4200`; edit `Cors:AllowedOrigins` in the API when changing the frontend origin. CORS handles JSON preflight requests and does not use wildcard origins or credentials.

## User flow

1. About you: name, email, optional telephone.
2. Your rental: street, optional unit, city, US state/DC, five-digit ZIP, residence type.
3. Your coverage: date, belongings limit, deductible; fixed liability and medical payments shown.
4. Submit: the server validates, calculates, and saves through EF Core before returning the summary and reference. Print or start a new quote.

Back navigation preserves inputs. The form validates each step, focuses the first invalid field, prevents double clicks during submission, and preserves entries on API errors. No contact information is stored in browser storage. Dates use UTC consistently and must be today through 90 days ahead. The app checks ZIP format but does not verify the address or ZIP/state match.

## Sample pricing

`backend/QuoteCalculator.cs` contains all illustrative rates:

```
Base monthly = 8 + (personal property coverage / 1000 × 0.25)
ZIP factor = 1.15 for ZIPs beginning 0, 1, or 9; otherwise 1.00
Residence factor = 1.10 for a house; otherwise 1.00
Deductible factor = 0.90 for $1,000; otherwise 1.00
Monthly = base × ZIP factor × residence factor × deductible factor, rounded to cents
Annual = rounded monthly × 12
```

Belongings choices: $15,000 / $25,000 / $50,000. Deductible: $500 / $1,000. Fixed liability: $100,000. Fixed medical payments: $1,000. Saved quotes include rating version `demo-v1`. These are not real insurance rates, carrier-approved rules, an offer of insurance, or a policy. No taxes, fees, discounts beyond the sample deductible factor, quote expiry, or underwriting are modeled.

## API

`POST /api/quotes` accepts:

```json
{
  "fullName": "Alex Demo",
  "email": "alex@example.com",
  "phone": "",
  "streetAddress": "123 Demo Street",
  "unit": "4B",
  "city": "Austin",
  "state": "TX",
  "zipCode": "78701",
  "residenceType": "Apartment",
  "coverageStartDate": "2026-10-01",
  "personalPropertyCoverage": 25000,
  "deductible": 500
}
```

Use a current start date when trying this example. Response: `201` with quote ID, selected and fixed coverages, monthly/annual premium, start date, rating version. Invalid input returns `400` validation details. A database save failure returns `503`; unexpected errors return a generic problem response. Premiums are always calculated server-side. There is no public quote listing/retrieval endpoint, authentication, resume flow, payment, email sending, or policy issuance. Refreshing starts a new form; saved quotes remain in SQL Server. Use fictional data for this local POC. A retry after a lost response may create another quote; idempotency is outside this POC.

## Verification

```powershell
dotnet build backend\Renters.Api.csproj
cd frontend
npm run build
cd ..
pwsh -File scripts\Test-Api.ps1
```

The smoke script requires the API and database to be running. It checks CORS allow/deny behavior, validation, successful SQL saves, pricing, rounding, date limits, and leading-zero ZIPs. It creates two fictional quotes each run. It requires PowerShell 7.

## Branding

The unmodified logo in `frontend/public/gallagher-logo.png` comes from the [Gallagher Brand Center](https://www.gallagherbrandcenter.com/logos/), specifically its [horizontal logo image](https://www.gallagherbrandcenter.com/media/1053/gallagher-horizontal.png). The header includes a text fallback. The application is explicitly labeled a POC; sample rates are not Gallagher-approved.

## Structure

- `backend/`: API, request validation, EF model/context, and one pricing service.
- `frontend/`: Angular component, reactive form, styles, and local brand asset.
- `database/`: repeatable SQL Server database/table setup script.
- `scripts/`: repeatable API smoke checks.

Framework references: [Angular version compatibility](https://angular.dev/reference/versions), [ASP.NET Core CORS](https://learn.microsoft.com/en-us/aspnet/core/security/cors?view=aspnetcore-8.0).
