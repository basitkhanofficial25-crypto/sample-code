param([string]$BaseUrl = 'http://localhost:5080')
$ErrorActionPreference = 'Stop'
$passed = 0
function Assert-That($condition, [string]$message) {
    if (-not $condition) { throw $message }
    $script:passed++
    Write-Host "PASS: $message"
}
function Send-Quote($body) {
    Invoke-WebRequest "$BaseUrl/api/quotes" -Method Post -ContentType 'application/json' -Body ($body | ConvertTo-Json) -SkipHttpErrorCheck
}
function New-Quote {
    @{
        fullName = 'Automated Demo'; email = 'test@example.com'; phone = ''; streetAddress = '123 Demo Street'; unit = ''
        city = 'Austin'; state = 'TX'; zipCode = '78701'; residenceType = 'Apartment'
        coverageStartDate = [DateTime]::UtcNow.ToString('yyyy-MM-dd'); personalPropertyCoverage = 25000; deductible = 500
    }
}
$health = Invoke-WebRequest "$BaseUrl/health"
Assert-That ($health.StatusCode -eq 200) 'API health'
$preflight = Invoke-WebRequest "$BaseUrl/api/quotes" -Method Options -Headers @{
    Origin='http://localhost:4200'; 'Access-Control-Request-Method'='POST'; 'Access-Control-Request-Headers'='content-type'
}
Assert-That ($preflight.Headers['Access-Control-Allow-Origin'] -contains 'http://localhost:4200') 'Angular origin allowed by CORS'
$blocked = Invoke-WebRequest "$BaseUrl/api/quotes" -Method Options -Headers @{
    Origin='https://untrusted.example'; 'Access-Control-Request-Method'='POST'
}
Assert-That (-not $blocked.Headers.ContainsKey('Access-Control-Allow-Origin')) 'Other origins receive no CORS permission'
foreach ($case in @(
    @{field='fullName'; value='   '}, @{field='email'; value='invalid'}, @{field='phone'; value='123'},
    @{field='zipCode'; value='1234'}, @{field='state'; value='ZZ'}, @{field='residenceType'; value='Castle'},
    @{field='personalPropertyCoverage'; value=12345}, @{field='deductible'; value=0},
    @{field='coverageStartDate'; value=[DateTime]::UtcNow.AddDays(-1).ToString('yyyy-MM-dd')},
    @{field='coverageStartDate'; value=[DateTime]::UtcNow.AddDays(91).ToString('yyyy-MM-dd')}
)) {
    $body = New-Quote
    $body[$case.field] = $case.value
    $response = Send-Quote $body
    Assert-That ($response.StatusCode -eq 400) "Reject invalid $($case.field): $($case.value)"
}
$body = New-Quote
$response = Send-Quote $body
Assert-That ($response.StatusCode -eq 201) 'Valid quote saved in SQL Server'
$quote = $response.Content | ConvertFrom-Json
Assert-That ($quote.monthlyPremium -eq 14.25 -and $quote.annualPremium -eq 171) 'Base quote calculation'
Assert-That ($quote.personalLiabilityCoverage -eq 100000 -and $quote.medicalPaymentsCoverage -eq 1000) 'Fixed coverages'
Assert-That ($null -ne [Guid]::Parse($quote.id)) 'Quote reference is a GUID'
$body.zipCode = '01234'; $body.residenceType = 'House'; $body.deductible = 1000
$body.coverageStartDate = [DateTime]::UtcNow.AddDays(90).ToString('yyyy-MM-dd')
$response = Send-Quote $body
$quote = $response.Content | ConvertFrom-Json
Assert-That ($response.StatusCode -eq 201 -and $quote.monthlyPremium -eq 16.22 -and $quote.annualPremium -eq 194.64) 'Region, house, deductible, rounding, leading-zero ZIP, and 90-day boundary'
Write-Host "All $passed checks passed. Two fictional quotes were saved."
