import { Component, inject, signal } from '@angular/core';
import { CurrencyPipe, DatePipe } from '@angular/common';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { AbstractControl, FormBuilder, ReactiveFormsModule, ValidationErrors, Validators } from '@angular/forms';
import { finalize, timeout } from 'rxjs';
import { environment } from '../environments/environment';

interface QuoteSummary {
  id: string; personalPropertyCoverage: number; deductible: number;
  personalLiabilityCoverage: number; medicalPaymentsCoverage: number;
  monthlyPremium: number; annualPremium: number; coverageStartDate: string; ratingVersion: string;
}
interface Field { key: string; label: string; type: string; autocomplete: string; max: number; optional?: boolean; }
const requiredText = (c: AbstractControl): ValidationErrors | null =>
  typeof c.value === 'string' && c.value.trim() ? null : { required: true };
const phone = (c: AbstractControl): ValidationErrors | null => {
  const value = c.value as string;
  if (!value) return null;
  const digits = value.replace(/\D/g, '').length;
  return /^[0-9+() .-]{7,30}$/.test(value) && digits >= 10 && digits <= 15 ? null : { phone: true };
};
const startDate = (c: AbstractControl): ValidationErrors | null => {
  const today = new Date().toISOString().slice(0, 10);
  const maximum = new Date(Date.now() + 90 * 86400000).toISOString().slice(0, 10);
  const value = c.value as string;
  const parsed = new Date(value);
  return /^\d{4}-\d{2}-\d{2}$/.test(value) && !isNaN(parsed.getTime()) &&
    parsed.toISOString().slice(0, 10) === value && value >= today && value <= maximum ? null : { startDate: true };
};

@Component({ selector: 'app-root', imports: [ReactiveFormsModule, CurrencyPipe, DatePipe], templateUrl: './app.html', styleUrl: './app.css' })
export class App {
  private readonly fb = inject(FormBuilder);
  private readonly http = inject(HttpClient);
  readonly step = signal(0);
  readonly saving = signal(false);
  readonly quote = signal<QuoteSummary | null>(null);
  readonly errors = signal<string[]>([]);
  readonly logoUnavailable = signal(false);
  readonly steps = ['About you', 'Your rental', 'Your coverage'];
  readonly states = 'AL AK AZ AR CA CO CT DE DC FL GA HI ID IL IN IA KS KY LA ME MD MA MI MN MS MO MT NE NV NH NJ NM NY NC ND OH OK OR PA RI SC SD TN TX UT VT VA WA WV WI WY'.split(' ');
  readonly today = new Date().toISOString().slice(0, 10);
  readonly maxDate = new Date(Date.now() + 90 * 86400000).toISOString().slice(0, 10);
  readonly contactFields: Field[] = [
    { key: 'fullName', label: 'Full name', type: 'text', autocomplete: 'name', max: 100 },
    { key: 'email', label: 'Email address', type: 'email', autocomplete: 'email', max: 254 },
    { key: 'phone', label: 'Phone number', type: 'tel', autocomplete: 'tel', max: 30, optional: true },
  ];
  readonly addressFields: Field[] = [
    { key: 'streetAddress', label: 'Street address', type: 'text', autocomplete: 'address-line1', max: 200 },
    { key: 'unit', label: 'Apartment or unit', type: 'text', autocomplete: 'address-line2', max: 30, optional: true },
    { key: 'city', label: 'City', type: 'text', autocomplete: 'address-level2', max: 100 },
    { key: 'zipCode', label: 'ZIP code', type: 'text', autocomplete: 'postal-code', max: 5 },
  ];
  readonly form = this.fb.nonNullable.group({
    fullName: ['', [requiredText, Validators.maxLength(100)]],
    email: ['', [Validators.required, Validators.email, Validators.maxLength(254)]],
    phone: ['', [phone, Validators.maxLength(30)]],
    streetAddress: ['', [requiredText, Validators.maxLength(200)]],
    unit: ['', Validators.maxLength(30)], city: ['', [requiredText, Validators.maxLength(100)]],
    state: ['', Validators.required], zipCode: ['', [Validators.required, Validators.pattern(/^[0-9]{5}$/)]],
    residenceType: ['Apartment', Validators.required],
    coverageStartDate: [this.today, [Validators.required, startDate]],
    personalPropertyCoverage: [25000, Validators.required], deductible: [500, Validators.required],
  });
  private readonly stepFields = [
    ['fullName', 'email', 'phone'], ['streetAddress', 'unit', 'city', 'state', 'zipCode', 'residenceType'],
    ['coverageStartDate', 'personalPropertyCoverage', 'deductible'],
  ];
  invalid(key: string): boolean { const c = this.form.get(key)!; return c.touched && c.invalid; }
  message(key: string): string {
    const errors = this.form.get(key)!.errors;
    if (errors?.['required']) return 'This field is required.';
    if (errors?.['email']) return 'Enter a valid email address.';
    if (errors?.['phone']) return 'Enter a phone number with 10 to 15 digits.';
    if (errors?.['startDate']) return 'Choose today or a date within the next 90 days (UTC).';
    if (key === 'zipCode') return 'Enter a five-digit ZIP code.';
    return 'Please check this value.';
  }
  next(): void {
    if (this.saving()) return;
    const controls = this.stepFields[this.step()].map(key => this.form.get(key)!);
    controls.forEach(c => { c.markAsTouched(); c.updateValueAndValidity(); });
    if (controls.some(c => c.invalid)) {
      setTimeout(() => document.querySelector<HTMLElement>('[aria-invalid="true"]')?.focus()); return;
    }
    if (this.step() < 2) { this.step.update(value => value + 1); this.focusHeading(); } else this.submit();
  }
  back(): void { if (!this.saving()) { this.errors.set([]); this.step.update(v => Math.max(0, v - 1)); this.focusHeading(); } }
  private submit(): void {
    this.form.controls.coverageStartDate.updateValueAndValidity();
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      this.step.set(this.stepFields.findIndex(keys => keys.some(key => this.form.get(key)!.invalid)));
      this.focusHeading(); return;
    }
    this.saving.set(true); this.errors.set([]);
    const body = Object.fromEntries(Object.entries(this.form.getRawValue()).map(([key, value]) =>
      [key, typeof value === 'string' ? value.trim() : value]));
    this.http.post<QuoteSummary>(`${environment.apiUrl}/quotes`, body).pipe(
      timeout(20000), finalize(() => this.saving.set(false)),
    ).subscribe({
      next: result => { this.quote.set(result); this.focusHeading(); },
      error: (error: HttpErrorResponse) => {
        if (error.status === 400 && error.error?.errors) this.errors.set(Object.values(error.error.errors as Record<string, string[]>).flat());
        else this.errors.set([error.status === 503 ? "We couldn't save your quote. Please try again shortly." :
          'We could not confirm that your quote was saved. Please check the API connection and try again.']);
        setTimeout(() => document.getElementById('quote-errors')?.focus());
      },
    });
  }
  restart(): void { this.quote.set(null); this.errors.set([]); this.form.reset(); this.step.set(0); this.focusHeading(); }
  print(): void { window.print(); }
  private focusHeading(): void { setTimeout(() => document.getElementById('step-heading')?.focus()); }
}
