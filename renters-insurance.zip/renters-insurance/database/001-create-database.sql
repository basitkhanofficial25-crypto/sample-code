-- Run in SSMS or with sqlcmd. Safe to rerun; does not replace existing data.
IF DB_ID(N'RentersInsurance') IS NULL
    CREATE DATABASE RentersInsurance;
GO
USE RentersInsurance;
GO
IF OBJECT_ID(N'dbo.Quotes', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Quotes (
        Id uniqueidentifier NOT NULL CONSTRAINT PK_Quotes PRIMARY KEY,
        FullName nvarchar(100) NOT NULL,
        Email nvarchar(254) NOT NULL,
        Phone nvarchar(30) NULL,
        StreetAddress nvarchar(200) NOT NULL,
        Unit nvarchar(30) NULL,
        City nvarchar(100) NOT NULL,
        State nvarchar(2) NOT NULL,
        ZipCode nvarchar(5) NOT NULL,
        ResidenceType nvarchar(20) NOT NULL,
        CoverageStartDate date NOT NULL,
        PersonalPropertyCoverage int NOT NULL,
        Deductible int NOT NULL,
        PersonalLiabilityCoverage int NOT NULL,
        MedicalPaymentsCoverage int NOT NULL,
        MonthlyPremium decimal(10,2) NOT NULL,
        AnnualPremium decimal(10,2) NOT NULL,
        RatingVersion nvarchar(20) NOT NULL,
        CreatedAtUtc datetime2 NOT NULL,
        CONSTRAINT CK_Quotes_Property CHECK (PersonalPropertyCoverage IN (15000, 25000, 50000)),
        CONSTRAINT CK_Quotes_Deductible CHECK (Deductible IN (500, 1000)),
        CONSTRAINT CK_Quotes_Residence CHECK (ResidenceType IN ('Apartment', 'Condo', 'House')),
        CONSTRAINT CK_Quotes_Premium CHECK (MonthlyPremium > 0 AND AnnualPremium = MonthlyPremium * 12)
    );
END;
GO
