using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Renters.Api;

[ApiController]
[Route("api/quotes")]
public sealed class QuotesController(QuoteDbContext db, QuoteCalculator calculator, ILogger<QuotesController> logger) : ControllerBase
{
    [HttpPost]
    public async Task<ActionResult<QuoteSummary>> Create(QuoteRequest request, CancellationToken cancellationToken)
    {
        var premium = calculator.Calculate(request);
        var quote = new Quote
        {
            FullName = request.FullName.Trim(), Email = request.Email.Trim(), Phone = request.Phone?.Trim(),
            StreetAddress = request.StreetAddress.Trim(), Unit = request.Unit?.Trim(), City = request.City.Trim(),
            State = request.State, ZipCode = request.ZipCode, ResidenceType = request.ResidenceType,
            CoverageStartDate = request.CoverageStartDate, PersonalPropertyCoverage = request.PersonalPropertyCoverage,
            Deductible = request.Deductible, MonthlyPremium = premium.Monthly, AnnualPremium = premium.Annual
        };
        db.Quotes.Add(quote);
        try { await db.SaveChangesAsync(cancellationToken); }
        catch (DbUpdateException)
        {
            logger.LogWarning("Quote could not be saved to the database.");
            return Problem(statusCode: 503, title: "We couldn't save your quote. Please try again shortly.");
        }
        return StatusCode(StatusCodes.Status201Created, new QuoteSummary(
            quote.Id, quote.PersonalPropertyCoverage, quote.Deductible, quote.PersonalLiabilityCoverage,
            quote.MedicalPaymentsCoverage, quote.MonthlyPremium, quote.AnnualPremium,
            quote.CoverageStartDate, quote.RatingVersion));
    }
}

public sealed record QuoteSummary(Guid Id, int PersonalPropertyCoverage, int Deductible,
    int PersonalLiabilityCoverage, int MedicalPaymentsCoverage, decimal MonthlyPremium,
    decimal AnnualPremium, DateOnly CoverageStartDate, string RatingVersion);
