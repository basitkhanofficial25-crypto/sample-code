namespace Renters.Api;

public sealed class Quote : QuoteRequest
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public int PersonalLiabilityCoverage { get; set; } = 100000;
    public int MedicalPaymentsCoverage { get; set; } = 1000;
    public decimal MonthlyPremium { get; set; }
    public decimal AnnualPremium { get; set; }
    public string RatingVersion { get; set; } = "demo-v1";
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
}
