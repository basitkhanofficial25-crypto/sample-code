namespace Renters.Api;

// Illustrative arithmetic only. These are not Gallagher or carrier rates.
public sealed class QuoteCalculator
{
    public (decimal Monthly, decimal Annual) Calculate(QuoteRequest request)
    {
        decimal region = request.ZipCode[0] switch { '0' or '1' or '9' => 1.15m, _ => 1m };
        decimal residence = request.ResidenceType == "House" ? 1.10m : 1m;
        decimal deductible = request.Deductible == 1000 ? 0.90m : 1m;
        decimal baseMonthly = 8m + request.PersonalPropertyCoverage / 1000m * 0.25m;
        decimal monthly = Math.Round(baseMonthly * region * residence * deductible, 2, MidpointRounding.AwayFromZero);
        return (monthly, monthly * 12);
    }
}
