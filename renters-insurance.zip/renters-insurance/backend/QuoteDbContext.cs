using Microsoft.EntityFrameworkCore;

namespace Renters.Api;

public sealed class QuoteDbContext(DbContextOptions<QuoteDbContext> options) : DbContext(options)
{
    public DbSet<Quote> Quotes => Set<Quote>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        var quote = modelBuilder.Entity<Quote>();
        quote.ToTable("Quotes", "dbo");
        quote.HasKey(q => q.Id);
        quote.Property(q => q.ZipCode).HasMaxLength(5);
        quote.Property(q => q.RatingVersion).HasMaxLength(20);
        quote.Property(q => q.MonthlyPremium).HasPrecision(10, 2);
        quote.Property(q => q.AnnualPremium).HasPrecision(10, 2);
    }
}
