using System.ComponentModel.DataAnnotations;

namespace Renters.Api;

public class QuoteRequest : IValidatableObject
{
    [Required, StringLength(100)] public string FullName { get; set; } = "";
    [Required, EmailAddress, StringLength(254)] public string Email { get; set; } = "";
    [StringLength(30), RegularExpression(@"^[0-9+() .-]{7,30}$", ErrorMessage = "Enter a valid phone number.")]
    public string? Phone { get; set; }
    [Required, StringLength(200)] public string StreetAddress { get; set; } = "";
    [StringLength(30)] public string? Unit { get; set; }
    [Required, StringLength(100)] public string City { get; set; } = "";
    [Required, StringLength(2)] public string State { get; set; } = "";
    [Required, RegularExpression(@"^[0-9]{5}$", ErrorMessage = "Enter a five-digit ZIP code.")]
    public string ZipCode { get; set; } = "";
    [Required, StringLength(20)] public string ResidenceType { get; set; } = "";
    public DateOnly CoverageStartDate { get; set; }
    public int PersonalPropertyCoverage { get; set; }
    public int Deductible { get; set; }

    public static readonly string[] States = "AL AK AZ AR CA CO CT DE DC FL GA HI ID IL IN IA KS KY LA ME MD MA MI MN MS MO MT NE NV NH NJ NM NY NC ND OH OK OR PA RI SC SD TN TX UT VT VA WA WV WI WY".Split(' ');

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (!States.Contains(State)) yield return new("Select a US state or DC.", [nameof(State)]);
        if (!new[] { "Apartment", "Condo", "House" }.Contains(ResidenceType))
            yield return new("Select a valid residence type.", [nameof(ResidenceType)]);
        if (!new[] { 15000, 25000, 50000 }.Contains(PersonalPropertyCoverage))
            yield return new("Select $15,000, $25,000, or $50,000.", [nameof(PersonalPropertyCoverage)]);
        if (!new[] { 500, 1000 }.Contains(Deductible))
            yield return new("Select a $500 or $1,000 deductible.", [nameof(Deductible)]);
        var today = DateOnly.FromDateTime(DateTime.UtcNow);
        if (CoverageStartDate < today || CoverageStartDate > today.AddDays(90))
            yield return new("Choose a start date from today through the next 90 days (UTC).", [nameof(CoverageStartDate)]);
        if (!string.IsNullOrEmpty(Phone) && (Phone.Count(char.IsDigit) < 10 || Phone.Count(char.IsDigit) > 15))
            yield return new("Use 10 to 15 digits for your phone number.", [nameof(Phone)]);
    }
}
