using Microsoft.EntityFrameworkCore;
using Renters.Api;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllers();
builder.Services.AddProblemDetails();
builder.Services.AddDbContext<QuoteDbContext>(options => options.UseSqlServer(
    builder.Configuration.GetConnectionString("RentersDb")));
builder.Services.AddSingleton<QuoteCalculator>();
builder.Services.AddCors(options => options.AddPolicy("Angular", policy => policy
    .WithOrigins(builder.Configuration.GetSection("Cors:AllowedOrigins").Get<string[]>() ?? [])
    .WithMethods("POST").WithHeaders("Content-Type")));
var app = builder.Build();
app.UseExceptionHandler();
app.UseCors("Angular");
app.MapControllers();
app.MapGet("/health", () => Results.Ok(new { status = "ok" }));
app.Run();
